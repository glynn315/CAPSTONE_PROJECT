<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" /> 
	<title></title>
</head>
<body>
<div class="container">  
	<?php
		    		if (isset($_POST["submit_coordinates"]))
					{
						$latitude = $_POST["z1"];
						$longitude = $_POST["z2"];
						?>

						<iframe width="100%" height="500" src="https://maps.google.com/maps?q=<?php echo $latitude; ?>,<?php echo $longitude; ?>&output=embed"></iframe>

						<?php
					}

		    	?>
			    	
</div>
<form method="POST">
	<div class="form-group mb-3">
                               	<label for="">LONGITUDE</label>
                               	<input type="text" id="retlong" name="z2" placeholder="LONGITUDE"  class="form-control">
                           	</div>
                           	<div class="form-group mb-3">
                               	<label for="">LATITUDE</label>
                               	<input type="text" id="retlat" name="z1" placeholder="LATITUDE"  class="form-control">
                           	</div>
                           	<div class="form-group mb-3">
                               	<label for="">Date</label>
                               	<input type="text" id="retdate" placeholder="DATE"  class="form-control">
                           	</div>
                           	<div class="form-group mb-3">
                               	<label for="">Status</label>
                               	<input type="text" id="retstat" placeholder="STATUS"  class="form-control">
                           	</div>
                           	<div class="form-group mb-3">
                               	<input type="submit" value="Locate" name="submit_coordinates" class="form-control btn btn-primary">
                           	</div>
</form>
<script>  
	$(document).ready(function(){  
    $('#employee_data').DataTable();  
 	});  
</script>  
</body>
</html>